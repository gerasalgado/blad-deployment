module.exports = {
    presets: [
      '@babel/preset-typescript',
    ],
  };