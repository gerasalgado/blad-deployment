export const BASE_URL = "https://catfact.ninja";
export const FACT = "/fact";
